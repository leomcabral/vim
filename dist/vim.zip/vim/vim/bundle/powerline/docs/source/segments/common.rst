***************
Common segments
***************

.. automodule:: powerline.segments.common
   :members:
